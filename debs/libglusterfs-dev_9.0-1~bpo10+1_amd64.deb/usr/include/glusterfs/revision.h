#define GLUSTERFS_REPOSITORY_REVISION "git://git.gluster.org/glusterfs.git"
